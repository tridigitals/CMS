<?php

namespace Modules\ContactForm\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\ContactForm\App\Models\ContactForm;
use Illuminate\Support\Facades\Mail;

class ContactFormController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $contacts = ContactForm::latest()->paginate(20);
        return view('contactform::index', compact('contacts'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('contactform::create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'nullable|string|max:255',
            'message' => 'required|string',
        ]);
        $contact = ContactForm::create($validated);
        // Kirim notifikasi email ke admin (opsional, bisa disesuaikan)
        // Mail::to(config('mail.from.address'))->send(new \\App\\Mail\\ContactFormSubmitted($contact));
        return redirect()->route('contactform.index')->with('success', 'Pesan berhasil dikirim!');
    }

    /**
     * Show the specified resource.
     */
    public function show($id)
    {
        $contact = ContactForm::findOrFail($id);
        return view('contactform::show', compact('contact'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $contact = ContactForm::findOrFail($id);
        return view('contactform::edit', compact('contact'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'subject' => 'nullable|string|max:255',
            'message' => 'required|string',
        ]);
        $contact = ContactForm::findOrFail($id);
        $contact->update($validated);
        return redirect()->route('contactform.index')->with('success', 'Data kontak berhasil diperbarui!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        $contact = ContactForm::findOrFail($id);
        $contact->delete();
        return redirect()->route('contactform.index')->with('success', 'Data kontak berhasil dihapus!');
    }
}
